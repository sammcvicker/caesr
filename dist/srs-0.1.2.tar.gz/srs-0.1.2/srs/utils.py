styles: dict = {
    "good": {
        "fg": "green",
        "bold": True
    },
    "bad": {
        "fg": "red",
        "bold": True
    },
}