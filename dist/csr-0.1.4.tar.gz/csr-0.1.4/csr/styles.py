styles: dict = {
    "good": {"fg": "green", "bold": True},
    "neutral": {"fg": "blue", "bold": True, "italic": True},
    "bad": {"fg": "red", "bold": True},
}
